globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/node_modules_next_6a1aad98._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__493166fd._.js",
      "static/chunks/src_pages_index_5771e187._.js",
      "static/chunks/src_pages_index_7b5977f1._.js"
    ],
    "/_app": [
      "static/chunks/node_modules_next_dist_4f3d469a._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__659f318b._.js",
      "static/chunks/src_styles_globals_4738091e.css",
      "static/chunks/src_pages__app_5771e187._.js",
      "static/chunks/src_pages__app_e16c4596._.js"
    ],
    "/book/[id]": [
      "static/chunks/node_modules_next_63387682._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__48718f72._.js",
      "static/chunks/src_pages_book_[id]_tsx_5771e187._.js",
      "static/chunks/src_pages_book_[id]_tsx_063a8d93._.js"
    ],
    "/home": [
      "static/chunks/node_modules_next_0419b436._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__8eff9bd1._.js",
      "static/chunks/src_pages_home_5771e187._.js",
      "static/chunks/src_pages_home_6123804a._.js"
    ],
    "/login": [
      "static/chunks/node_modules_next_63387682._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__32a52f19._.js",
      "static/chunks/src_pages_login_5771e187._.js",
      "static/chunks/src_pages_login_2b3c1cd9._.js"
    ],
    "/profile": [
      "static/chunks/node_modules_next_dist_4f3d469a._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__0d5c56ba._.js",
      "static/chunks/src_pages_profile_5771e187._.js",
      "static/chunks/src_pages_profile_ffee9831._.js"
    ],
    "/signup": [
      "static/chunks/node_modules_next_63387682._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_2a5cf4bb._.js",
      "static/chunks/[root-of-the-server]__bfe74613._.js",
      "static/chunks/src_pages_signup_5771e187._.js",
      "static/chunks/src_pages_signup_449487e5._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];