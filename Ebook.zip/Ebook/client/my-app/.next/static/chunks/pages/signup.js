__turbopack_load_page_chunks__("/signup", [
  "static/chunks/node_modules_next_63387682._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__bfe74613._.js",
  "static/chunks/src_pages_signup_5771e187._.js",
  "static/chunks/src_pages_signup_449487e5._.js"
])
