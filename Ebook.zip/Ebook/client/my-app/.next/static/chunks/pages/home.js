__turbopack_load_page_chunks__("/home", [
  "static/chunks/node_modules_next_0419b436._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__8eff9bd1._.js",
  "static/chunks/src_pages_home_5771e187._.js",
  "static/chunks/src_pages_home_6123804a._.js"
])
