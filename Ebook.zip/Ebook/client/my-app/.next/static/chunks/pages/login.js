__turbopack_load_page_chunks__("/login", [
  "static/chunks/node_modules_next_63387682._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__32a52f19._.js",
  "static/chunks/src_pages_login_5771e187._.js",
  "static/chunks/src_pages_login_2b3c1cd9._.js"
])
